#pragma once
#include<iostream>

using namespace std;

class Part{
public:
    int id;
    Part(int _id) : id(_id) {};
};