#include"motor.h"

void Motor::sell() {
    cout << "A motor is sold!" << endl;
}