#include <iostream>
using namespace std;

class A
{
public:
    A()
    {
        cout << "A() is called." << endl;
    }
};

class B
{
public:
    A a;

public:
    B();
};