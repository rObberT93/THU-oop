#include <iostream>
   using namespace std;
   
  class A
  {
public:
    int a;
    A(){}
  }; 
  class B:public A
  {
      B():a(1){}
  };
int main() 
{
        
}