#pragma once
#include <vector>
#include <iostream>
using namespace std;

class Instruction
{
public:
    
    virtual void apply(std::vector<int> &vec) = 0;
    virtual void apply(std::vector<double> &vec) = 0;
    virtual void output() = 0;
    virtual int& get_num() = 0;
    
};

class Instruction1: public Instruction
{
 public:   
    int index;
    int num;
    int add_index;
    int add_num;
    int add_type;//0:add n   1:add index 2:assign 3:needs to be cout -1:leave it

    Instruction1(){}
    Instruction1(int _index, int _num):index(_index), num(_num), add_type(-2)
    {

    }
    Instruction1 operator=(const Instruction1& a)
    {
        num = a.num;
        add_type = 2;
        add_index = a.index;
        return *this;
    }
    Instruction1& operator+= (Instruction1 a)
    {
        num += a.num;
        add_index = a.index;
        add_type = 1; 
        return *this;
    }
    Instruction1& operator+= (int a)
    {
        num += a;
        add_num = a;
        add_type = 0;
        return *this;
    }
    virtual void apply(std::vector<int> &vec)
    {
        if(add_type == 0)
        {
            vec[index] += num;
        }
        else if(add_type == 1)
        {
            vec[index] += vec[add_index];
        }
        else if(add_type == 2)
        {
            vec[index] = vec[add_index];
        }
        else if(add_type == 3)
        {
            cout << vec[index] << endl;
        }
        return;
    }
    virtual void apply(std::vector<double> &vec)
    {
        if(add_type == 0)
        {
            vec[index] += num;
        }
        else if(add_type == 1)
        {
            vec[index] += vec[add_index];
        }
        else if(add_type == 2)
        {
            vec[index] = vec[add_index];
        }
        else if(add_type == 3)
        {
            cout << vec[index] << endl;
        }
        return;
    }
    virtual void output()
    {
        if(add_type == 0)
        {
            cout << "arr[" << index << "] += " << add_num << endl;
        }
        else if(add_type == 1)
        {
            cout << "arr[" << index << "] += " <<"arr[" << add_index << "]" << endl;
        }
        else if(add_type == 2)
        {
            cout << "arr[" << index << "] = " <<"arr[" << add_index << "]" << endl;
        }
        else if(add_type == 3)
        {
            cout << "cout << arr[" << index << "]" << endl;
            cout << "cout << endl" << endl;
        }
        
    }
    int& get_num()
    {
        return num;
    }
};

