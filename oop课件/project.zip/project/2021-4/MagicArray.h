#pragma once
#include <vector>
#include <iostream>
#include "Instruction.h"
#include <functional>
using namespace std;


class MagicArray
{
public:
    int length;
    int times;
    vector<Instruction*> instructions;
    vector<int> arr{0};
    Instruction1* p1;
    friend ostream& operator<< (ostream& c, Instruction1& a);
    MagicArray(int l):length(l),times(0)
    {

    }
    Instruction1& operator[](int i)
    {
        
        Instruction* p = new Instruction1(i, 0);
        instructions.push_back(p);
        p1 = dynamic_cast<Instruction1*>(p);
        return *p1;
    }
    void apply(vector<int> &vec)
    {
        for(auto &x : instructions)
        {
            
            x->apply(vec);
        }
    }
    void apply(vector<double> &vec)
    {
        for(auto &x : instructions)
        {
            x->apply(vec);
            //cout << vec[0] << endl;
        }
    }
    vector<Instruction*>& getInstructions()
    {
        return instructions;
    }
    Instruction1& endl()
    {
        Instruction1* p = new Instruction1();
        p->add_type = -1;
        return *p;
    }
};

ostream& operator<< (ostream& c, Instruction1 &a)
{
    if(a.add_type != -1)
    {
        a.add_type = 3;
    }
    
    return c;
}
