#include "operation_pm.h"

void OperationNodePlus::UpdateValue()
{
    value_=input1->value()+input2->value();
}

void OperationNodeMinus::UpdateValue()
{
    value_=input1->value()-input2->value();
}

