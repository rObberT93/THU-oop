#include <cstring>
#pragma once

class Task
{
public:
    char s[30];
    int d;
    int n;
    int m;
    int the_server[110];
    int start_time;
    int flag;

public:
    Task(char* a, int d, int n, int m);
    Task();
};
