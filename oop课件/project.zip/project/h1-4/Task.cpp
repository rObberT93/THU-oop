#include "Task.h"
#include "Server.h"


Task::Task(char* a, int d, int n, int m):d(d), n(n), m(m)
    {
        strcpy(s, a);
        flag = 1;
    }
Task::Task(){}
