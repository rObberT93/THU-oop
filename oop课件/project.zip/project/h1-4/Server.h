#include "Task.h"
#pragma once

class Server
{
public:
    int n;
    int m;
    int servers[110];


public:
    Server(int n, int m);
    bool submit_task(Task task);


    bool cancel_task(char* s);
    

    void tick();
    

};