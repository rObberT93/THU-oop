#include "Server.h"
#include "Task.h"
#include "cstring"
#include <iostream>
using namespace std;

int s_count = 0;//submit 的个数
int now_time = 0;//time 现在的时间
Task tasks[210];

 Server::Server(int n, int m) : n(n), m(m)
 {
     for(int e = 1; e <= n; e++)
     {
        servers[e] = m;
     }
     
 }

bool Server::submit_task(Task task)
    {
        s_count++;
        tasks[s_count] = task;
        tasks[s_count].flag = 1;
        tasks[s_count].start_time = now_time;
        int t = 1;
        int list[110] = {0};
        if(tasks[s_count].start_time == 245)
        {
           //cout <<"HERE: "<<servers[1]<<endl;
           //cout<<now_time - tasks[2].start_time<<endl;
            //cout<<s_count<<endl;
        }
        for(int e = 1; e <= n; e++)
        {
            if(servers[e] >= tasks[s_count].m)
            {
                tasks[s_count].the_server[t] = e;
                list[t] = e;
                t++;
                servers[e] -= tasks[s_count].m;
            }
            if(t == task.n + 1)
            {
                //cout<<endl;
                    for(int f = 1; f <= task.n; f++)
                    {
                       //cout << list[f]<< ": "<<servers[list[f]] << endl;
                    }
                    //cout<<servers[10]<<endl;
                
                return true;
            }
        }
        t--;
        for(int i = 1; i <= t; i++)
        {
            servers[list[i]] += tasks[s_count].m;
            //cout<<list[i]<<": "<<servers[list[i]]<<endl;
        
        }
        //cout<<endl;
        for(int i = 1; i <= n; i++)
        {
            tasks[s_count].the_server[i] = 0;
        }
        //cout<<now_time<<endl;
        s_count--;
        //now_time = tasks[s_count].start_time;
        //cout<<"time: "<<now_time<<endl;
        //cout<<servers[1]<<endl;
        return false;
        
    }

bool Server::cancel_task(char* s)
    {
        for(int i = 1; i <= s_count; i++)
        {
            if(strcmp(tasks[i].s, s) == 0 && now_time - tasks[i].start_time < tasks[i].d && tasks[i].n > 0)
            {
                for(int j = 1; j <= tasks[i].n; j++)
                {
                    servers[tasks[i].the_server[j]] += tasks[i].m;
                }
                tasks[i].n = 0;
                tasks[i].m = 0;
                tasks[i].d = 0;
                tasks[i].flag = 0;
                return true;
            }
        }
        
        return false;
    }

void Server::tick()
    {
        now_time++;
        if(now_time == 245)
                    {
                        //cout<<"TIME IS UP"<<endl;
                        //cout<<servers[1]<<endl;
                        //cout<<tasks[2].flag<<endl;
                    }
        for(int e = 1; e <= s_count; e++)
        {
            if(tasks[e].flag == 1)
            {
                for(int j = 1; j <= tasks[e].n; j++)
            {
                if(now_time - tasks[e].start_time >= tasks[e].d)
                {
                    servers[tasks[e].the_server[j]] += tasks[e].m;
                    tasks[e].flag = 0;
                    
                }
            }
            }
            
        }
    }