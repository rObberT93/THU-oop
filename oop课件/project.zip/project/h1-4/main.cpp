#include <iostream>
#include "Task.h"
#include "Server.h"
#include "time.h"
using namespace std;

int main()
{
    clock_t start_time, end_time;
    start_time = clock();

    int N;
    int M;
    cin >> N >> M;
    Server server(N, M);
    int o;
    cin >> o;
    int cur_time = 0;
    for(int i = 0; i < o; i++) 
    {
        int t, d, n, m;
        char o;
        char s[30];//s:name of the task
        cin >> t >> o;//o:type of the task
        scanf("%s", s);
        for (int j = 0; j < t - cur_time; j++)
            server.tick();
        cur_time = t;
        if(o == 's')
        {
            cin >> n >> m >> d;
            Task task(s, d, n, m);
            if(server.submit_task(task))
            {
                cout << "Accepted " << s << endl;
            }
            else
            {
                cout << "Rejected " << s << endl;
            }
        }
        else if(o == 'c')
        {
            if(server.cancel_task(s))
            {
                cout << "Cancelled " << s << endl;
            }
            else
            {
                cout << "Not found " << s << endl;
            }
        }
        else
        {
            cout << "Invalid operation" << endl;
        }
    }

    /*end_time = clock();
    double Times = (double)(end_time - start_time) / CLOCKS_PER_SEC;
    printf("%f seconds\n", Times);*/
    return 0;
}
