#pragma once
#include <iostream>
using namespace std;

class Fraction
{
public:
    long long int up;
    long long int down;
    Fraction(){}
    Fraction(long long int u, long long int d = 1):up(u), down(d)
    {
        if(down != 1)
        {
            int lower = up > down ? down : up;
            int i = 2;
            while(i <= lower)
            {
                if(up % i == 0 && down % i == 0)
                {
                    up = up/i;
                    down = down / i;
                    lower = lower/i;
                }
                else
                {
                    i++;
                }
            }
        }
        
    }
    
};

Fraction operator*(Fraction& a, Fraction& b)
{
    return Fraction(a.up*b.up, a.down*b.down);
}
Fraction operator/(Fraction& a, Fraction& b)
{
    return Fraction(a.up*b.down, a.down*b.up);
}
Fraction operator+(Fraction& a, Fraction&b)
{
    return Fraction(a.up*b.down + b.up * a.down, a.down*b.down);
}
Fraction operator-(Fraction& a, Fraction&b)
{
    return Fraction(a.up*b.down - b.up * a.down, a.down*b.down);
}
