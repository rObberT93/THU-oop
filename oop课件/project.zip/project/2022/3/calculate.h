#pragma once
#include <iostream>
#include "Fraction.h"
using namespace std;

template<typename T>
class calculate
{
public:
    char expression;
    long long int x;
    long long int y;
    long long int z;
    T result;
    calculate(char e, int _x, int _y, int _z);
    
    friend ostream& operator<<(ostream& out, calculate<T>& c);
};

template<>
calculate<int>::calculate(char e, int _x, int _y, int _z):expression(e), x(_x), y(_y), z(_z)
{
    if(expression == 'A')
    {
        result =  x*x + y*y + z*z;
    }
    else if(expression == 'B')
    {
        result = x*y + y/z - x*z;
    }
    else
    {
        result = y*3*z - x*z/(y-2) - x*y/(z+1);
    }

}
ostream& operator<<(ostream& out, calculate<int> c)
{
    cout << c.result << endl;
    return out;
}

template<>
calculate<Fraction>::calculate(char e, int _x, int _y, int _z):expression(e), x(_x), y(_y), z(_z)
{
    
    if(expression == 'A')
    {
        result =  x*x + y*y + z*z;
    }
    else if(expression == 'B')
    {
        result = x*y + y/z - x*z;
        //cout << x * x << endl;
    }
    else
    {
        Fraction t(3, 2);
        
        result = Fraction(y,1)*Fraction(z,1) + y*z + y*z - (Fraction)x*z/(Fraction)(y-2) - x*y/(z+1);
        cout << y/z << endl;
    }

}
ostream& operator<<(ostream& out, calculate<Fraction> c)
{
    if(c.result.down != 1)
    {
        cout << c.result.up <<"/" << c.result.down << endl;
    }
    else
    {
        cout << c.result.up << endl;
    }
    return out;
}