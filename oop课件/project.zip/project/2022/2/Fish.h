#pragma once
#include "Animal.h"
#include <iostream>
using namespace std;

class Fish: public Animal
{
public:
    string c;
    int color;
    ~Fish()
    {
        cout << c << " fish is gone." << endl;
    }
    Fish(int _color):color(_color){
        if (color == 0)
        {
            c = "Red";
        }
        else
        {
            c = "Blue";
        }
    }
    void sing()
    {
        cout << "Fish can not sing." << endl;
    }
    void swim()
    {
        cout << c << " fish is swimming." << endl;
    }
};