#pragma once
#include "Animal.h"
#include <iostream>
using namespace std;

class Bird: public Animal
{
public:
    string c;
    int color;
    ~Bird()
    {
        cout << c << " bird is gone." << endl;
    }
    Bird(int _color):color(_color){
        if (color == 0)
        {
            c = "Red";
        }
        else
        {
            c = "Blue";
        }
    }
    void sing()
    {
        cout << c <<" bird is singing." << endl;
    }
    void swim()
    {
        cout << "Bird can not swim." << endl;
    }
};