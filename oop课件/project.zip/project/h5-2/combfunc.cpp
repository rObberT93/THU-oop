#include "combfunc.h"

CombFunc::CombFunc(Func *fun_1, Func *fun_2, double coe_1, double coe_2):_fun1(fun_1), _fun2(fun_2), _c1(coe_1), _c2(coe_2)
{
    
   
    
}
CombFunc::~CombFunc()
{
    if(_fun1)
    {
        delete _fun1;
    }
    if(_fun2)
    {
        delete _fun2;
    }
}
double CombFunc::getPoint(double point)
{
    return _c1 * _fun1->getPoint(point) + _c2 * _fun2->getPoint(point);
}