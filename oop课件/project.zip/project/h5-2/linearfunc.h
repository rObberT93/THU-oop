#pragma once

#include "func.h"

class LinearFunc : public Func{
private:
    
public:
    double _a;
    double _b;
    LinearFunc(double a, double b):_a(a),_b(b){}
    // Todo
    // 请参照指数函数类(ExpFunc)实现一个一次函数类
    // f(x) = ax + b;
    double getPoint(double point)override
    {
        return (_a*point + _b );
    }
    ~LinearFunc(){};
};