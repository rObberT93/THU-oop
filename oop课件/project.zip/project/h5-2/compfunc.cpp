#include "compfunc.h"
#include <iostream>
using namespace std;

CompFunc::CompFunc(Func *outer, Func* inner):_outer(outer), _inner(inner)
{
    /*
    *_outer = *outer;
    *_inner = *inner;
    outer = nullptr;
    inner = nullptr;
    */
}
double CompFunc::getPoint(double point)
{
    double tmp = _inner->getPoint(point);

    return _outer->getPoint(tmp);
}
CompFunc::~CompFunc()
{
    if(_outer)
    {
        delete _outer;
    }
    if(_inner)
    {
        delete _inner;
    }
}
