#pragma once
#include <iostream>
#include <sstream>
#include <string>
#include <map>
using namespace std;

class LoadStrategy {	
public:
    virtual float load()
    {
        return 0;
    }
    LoadStrategy(){}
};


class NumberLoadStrategy : public LoadStrategy {
public:
    float number;
    float load()
    {
        cin >> number;
        return number;
    }
};

class WordLoadStrategy : public LoadStrategy {
public:
    string line;
    map<string, int> a;
    float number;
    WordLoadStrategy():number(0)
    {
        a["one"] = 1;
        a["two"] = 2;
        a["three"] = 3;
        a["four"] = 4;
        a["five"] = 5;
        a["six"] = 6;
        a["seven"] = 7;
        a["eight"] = 8;
        a["nine"] = 9;
        a["zero"] = 0;
        
    }
    float load()
    {
        getline(cin, line, '#');
        //cout << line << endl;
        line.erase(line.begin() + line.length() - 1);
        istringstream iss(line);
        string word;
        while(iss >> word)
        {
            //cout << word << endl;
            number = number * 10 + a[word];
        }
        return number;

    }
    

};
