#pragma once
#include "LoadStrategy.h"
#include "PayStrategy.h"

class Calculator {	
public:
    LoadStrategy* l;
    PayStrategy* p;
    float load()
    {
        return l->load();
    }
    float pay(float money)
    {
        return p->pay(money);
    }
    Calculator(LoadStrategy* &ll, PayStrategy* &pp):l(ll), p(pp)
    {

    }

};