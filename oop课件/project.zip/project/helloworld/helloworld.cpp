#include <iostream>
#include <cstdlib>
#include "test.h"
using namespace std;

int main()
{
    
    
    
    cout<<"HI"<<endl;
}