//test.h
#pragma once
int Add(int a, int b)
{
    return a + b;
}
;