#pragma once
#include <iostream>
#include <string>
using namespace std;

class Friend
{
public:
    int _id;
    string** _record;
    int _mesCount = 0;
    Friend(int id);
    void addMes(string mes);
};