#include <iostream>
#include "friend.h"
#include <sstream>
using namespace std;

int N, M;
Friend** friends;

void Pin(int i)
{

}

int main()
{
    cin >> N;
    for(int i = 0; i < N; i++)
    {
        int id;
        string line;
        cin >> id >> line;
        friends[i] = new Friend(id);
        istringstream is(line);
        for(string mes; getline(is, mes, '/'); )
        {
            friends[i]->addMes(mes);
        }
    }
    cin >> M;
    for(int i = 0; i < M; i++)
    {
        int newId;
        string newMes;
        cin >> newId >> newMes;
        int flag = 0;
        for(int i = 0; i < N; i++)
        {
            if(friends[i]->_id == newId)
            {
                flag = 1;
                friends[i]->addMes(newMes);
            }
        }
    }
}