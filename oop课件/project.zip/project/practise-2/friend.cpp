#include "friend.h"
Friend::Friend(int id): _id(id)
{
    _record = new string*[1010];
}
void Friend::addMes(string mes)
{
    _record[_mesCount] = new string(mes);
    _mesCount++;
}