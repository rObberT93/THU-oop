#include <iostream>

float increase(int a);
int increase(int a) { return a + 1; }

int main() {
    std::cout << increase(1) << std::endl;
    return 0;
}
