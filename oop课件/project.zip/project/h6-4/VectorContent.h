#pragma once
#include "Object.h"
#include <vector>
using namespace std;
class Content;
class Object;

