#pragma once
#include <list>
#include <iostream>
#include <memory>
using namespace std;
#include "CustomClass.h"
class Object;
class Content
{
public:
	virtual void output(std::ostream& out){ //virtual function for output
		std::cout << "the operator is not supported for this type." << std::endl;
	}
	virtual void operator+=(int y)
	{

	}
	virtual void operator+=(string y)
	{

	}
	
};

class IntContent: public Content
{
private:
	int x;
public:
	IntContent(int _x): x(_x) {}
	void output(std::ostream& out){ 
		out << x;
		
	}
	void operator+=(int y)
	{
		x += y;
	}
};
class StringContent: public Content
{
private:
	std::string x;
public:
	StringContent(std::string _x): x(_x) {}
	void output(std::ostream& out){  
		out << x;
	}
	void operator+=(string s)
	{
		x += s;
	}
};

class CustomContent: public Content
{
private:
	CustomClass x;
public:
	CustomContent(const CustomClass& _x): x(_x) {}
};

class VectorContent;

class Object
{
private:
	shared_ptr<Content> pt;

public:
	Object() {}
	Object(int x) {
		pt = make_shared<IntContent> (x); 
	}
	Object(const std::string &x){
		pt = make_shared<StringContent> (x);
	}
	// The following codes are not working
	Object(const std::vector<Object> &x);
	Object(const CustomClass &x){
		pt = make_shared<CustomContent> (x);
	}

	friend std::ostream& operator<<(std::ostream& out, const Object& obj) {
		obj.pt->output(out);
		return out;
	}

	Object& operator+=(int y){
		pt->operator+=(y);
		return *this;
	}
	Object& operator+=(const std::string &y){
		pt->operator+=(y);
		return *this;
	}
	Object& operator[](int index);


	//need more operators......
};
class VectorContent: public Content
{

	
public:
	VectorContent(const std::vector<Object>& _x): x(_x) {}
	std::vector<Object> x; 
	
};
Object::Object(const std::vector<Object> &x){
		pt = make_shared<VectorContent> (x);
	}
Object& Object::operator[](int index)
	{
		shared_ptr<VectorContent> p = dynamic_pointer_cast<VectorContent>(pt);
		return p.get()->x[index];

	}
