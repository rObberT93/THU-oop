#include "School.h"
#include "Student.h"
#include <algorithm>
using namespace std;

//vector <Student> students; 
bool cmp1(Student a, Student b)
{
    return a.time > b.time || (a.time == b.time && a.Number > b.Number);
}

School::School(int n):N(n+1)
{
    Student first(0);
    students.push_back(first);
}
void School::add_member(Student s)
{
    students.push_back(s);
}

Student School::operator[](int sid)
{
    students[0].flag = 1;
    for(int i = 1; i <= N; i++)
    {
        if(students[i].Number == sid)
        {
            return students[i];
        }
    }
    students[0].flag = 0;
    return students[0];
}


    Student School::operator[](string name)
    {
        students[0].flag = 1;
        for(int i = 1; i <= N; i++)
        {
            if(students[i].Name == name)
            {
                return students[i];
            }
        }
        students[0].flag = 0;
        return students[0];
    }
    Student School::operator[](char p)
    {
        vector<Student> ps;
        students[0].flag = 1;
        for(int i = 1; i <= N; i++)
        {
            if(students[i].P == p)
            {
                ps.push_back(students[i]);
            }
        }
        if(ps.size() == 0)
        {
            students[0].flag = 0;
            return students[0];
        }
        else
        {
            sort(ps.begin(), ps.begin()+ ps.size(), cmp1);
            ps[0].flag = 1;
            return ps[0];
        }
        
    }