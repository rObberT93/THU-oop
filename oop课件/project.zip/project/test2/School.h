#include "Student.h"
#include <vector>
#pragma once
class School
{
public:
    int N;//number of students+1
    vector<Student> students;
public:
    School(int n);
    void add_member(Student s);
    Student operator[](int sid);
    Student operator[](string name);
    Student operator[](char p);
};