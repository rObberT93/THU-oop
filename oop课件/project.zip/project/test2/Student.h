#include <string>
#include <iostream>
using namespace std;
#pragma once
class Student
{
public:
    string Name;
    char P;
    int Grade;
    int Number;
    int time;
    bool flag;
public:
    Student();
    Student(bool flag);
    void Print();
};

istream& operator>> (istream& in, Student& s);
ostream& operator<< (ostream& out, const Student& s);