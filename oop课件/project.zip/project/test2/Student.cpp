#include "Student.h"
#include <string>
#include <iostream>
#include <iomanip>
#include <algorithm>
using namespace std;

Student::Student():flag(1){}
Student::Student(bool flag):flag(flag){}
istream& operator>> (istream& in, Student& s)
{
    string t;
    cin >> t;
    string a = "-";
    int post = -1;
    for(int i = 0; i <= 3; i++)
    {
        int temp = post;
        post = t.find(a, post+1);
        if(i == 0)
        {
            s.Name = t.substr(temp+1, post-temp-1);
        }
        else if(i == 1)
        {
            s.P = t[post-1];
        }
        else if(i == 2)
        {
            s.Grade = t[post-1] - '0';
        }
        else if(i == 3)
        {
            s.time = (t[temp+1]-'0')*1000+(t[temp+2]-'0')*100+(t[temp+3]-'0')*10+t[post-1]-'0';
            s.Number = 0;
            for(int j = 0; j <= 5; j++)
            {
                s.Number = t[post+1+j]-'0' + s.Number*10;
            }
        }
        
    }
    return in;
}

ostream& operator<< (ostream& out, const Student& s)
{
    if(s.flag == 0)
    {
        cout << "Not Found" << endl;
    }
    else{
        cout << s.Name << "-";
        cout << setw(4) << setfill('0') << s.time << '-' << s.Grade << '-' << s.Number << endl;
        
    }
    return out;
}