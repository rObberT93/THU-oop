#include <iostream>
#include "School.h"
#include "Student.h"
#include "time.h"
using namespace std;

int main(){
	clock_t start_time, end_time;
	start_time = clock();
	int n;
	cin >> n;
	School tsinghua(n);
	for (int i = 0; i < n; ++ i){
		Student s;
		cin >> s;
		tsinghua.add_member(s);
	}

	int m;
	cin >> m;
	for (int i = 0; i < m; ++ i){
		int type;
		cin >> type;
		if (type == 0){
			int sid;
			cin >> sid;
			cout << tsinghua[sid];
		}
		else if (type == 1) {
			string name;
			cin >> name;
			cout << tsinghua[name];
		}
		else if (type == 2){
			char province;
			cin >> province;
			cout << tsinghua[province];
		}
	}
	end_time = clock();
	double Times = (double)(end_time - start_time)/CLOCKS_PER_SEC;
	cout << Times << endl;
	return 0;
}