#pragma once

#include <string>

#include "Hash.h"

template <typename T1, typename T2>
class HashTable
{
public:
    int N;
    T2 **array;
    HashTable(int n);
    void addItem(const T1 &key, const T2 &value);
    void removeItem(const T1 &key);
    T2 *findByKey(const T1 &key);
};

template<typename T1, typename T2>
HashTable<T1, T2>::HashTable(int n):N(n)
{
    array = new T2*[N];
   for(int i = 0; i < N; i++)
   {
       array[i] = nullptr;
   }
    

}

template<typename T1, typename T2>void 
HashTable<T1, T2>::addItem(const T1 &key, const T2 &value)
{
    Hash<T1> a(N);
    int index = a.operator()(key);
    if(array[index] == nullptr)
    {
        array[index] = new T2(value);
    }
    else
    {
        delete array[index];
        array[index] = new T2(value);
    }
    
}

template<typename T1, typename T2> void
HashTable<T1, T2>::removeItem(const T1 &key)
{
    Hash<T1> a(N);
    int index = a.operator()(key);
    if(array[index] != nullptr)
    {
        array[index] = nullptr;
    }
}

template<typename T1, typename T2> T2*
HashTable<T1, T2>::findByKey(const T1 &key)
{
    Hash<T1> a(N);
    int index = a.operator()(key);
    
       return array[index];
    
}
