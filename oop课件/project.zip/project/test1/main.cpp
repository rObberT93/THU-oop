/*#include <iostream>
#include <string>
using namespace std;
int t = 0;
void f(string a)
{
    t++;
    cout << a << endl;
}
void f(string a, bool b)
{
    t++;
    if(b == 1)
    {
        for(int i = 1; i <= t; i++)
        {
            cout << a << endl;
        }
    }
    else
    {
        cout << a << endl;
    }
}

int main()
{
    f("a0");
    f("a1");
    f("a2", true);
    f("a3", false);
    f("a4", true);
}
*/

class A
{
public:
    static const int i;
};
 const int A::i = 1;
