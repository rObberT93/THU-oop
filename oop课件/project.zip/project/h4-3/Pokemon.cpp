#include "Pokemon.h"
#include <string>
#include <iostream>
using namespace std;
Pokemon::Pokemon(int hp, int atk, string name):tot_hp(hp), hp(hp), atk(atk), name(name)
{

}

Pokemon::Pokemon()
{

}
void Pokemon::use_skill(int idx, Pokemon* target)// 对目标target使用idx号技能
{

}
void Pokemon::hurt(int dmg, Pokemon* from)// 受到来自from的dmg点伤害时的反应
{

}
string Pokemon::get_name()  // 获取宝可梦名字
{
    return name;
}
bool Pokemon::alive()   // 宝可梦是否存活
{
    if(get_hp() > 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}
int Pokemon::get_hp()    // 获取生命值
{
    return hp;
}
int Pokemon::get_atk() // 获取攻击力
{
    return atk;
}
Pokemon::~Pokemon()
{

}


Squirtle::Squirtle(int hp, int atk, string name):Pokemon(hp, atk, name)
{
    
} 
void Squirtle::use_skill(int idx, Pokemon* target) 
{
    if(idx == 0)
    {
        if(hp + tot_hp / 5 <= tot_hp)
        {
            hp += tot_hp / 5;
        }
        else
        {
            hp = tot_hp;
        }
        cout << get_name() <<" used Regen" << endl;
    }
    else if(idx == 1)
    {
        Pokemon* p = this;
        
        cout << get_name() << " used Splash to " << target->get_name() << endl;
        target->hurt(atk, p);
    }
}
void Squirtle::hurt(int d, Pokemon* from)
{
    if(hp <= tot_hp / 5 && d / 2 >= 1)
    {
       hp -= d / 2;
       cout << get_name() << " received " << d / 2 << " damage from " << from->get_name() << endl;
    }
    else
    {
        hp -= d;
        cout << get_name() << " received " << d << " damage from " << from->get_name() << endl;

    }
    
}


Charizard::Charizard(int hp, int atk, string name):Pokemon(hp, atk, name), fire(1)
{

}
void Charizard::use_skill(int idx, Pokemon* target) 
{
    if(idx == 0)
    {
        fire++;
        atk *= 2;
        hp -= fire*10;
        cout << get_name() <<" used Ignite" << endl;
        cout << get_name() << " received " << fire*10 << " damage from " << get_name() << endl;
    }
    else if(idx == 1)
    {
        Pokemon* p = this;
        
        cout << get_name() << " used Flame to " << target->get_name() << endl;
        target->hurt(atk, p);
    }
}
void Charizard::hurt(int d, Pokemon* from)
{
    hp -= d;
    cout << get_name() << " received " << d << " damage from " << from->get_name() << endl;

    if(d > 10)
    {
       Pokemon* p = this;
       from ->hurt(d / 5, p);
      
      
    }
    
    
    
    
    
}
