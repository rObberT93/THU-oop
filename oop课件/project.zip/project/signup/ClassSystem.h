#pragma once
#include <string>
#include "Student.h"
#include <vector>
using namespace std;
class ClassSystem
{
public:
    vector<Student> students;
    int ClassNumber;
    
public:
    ClassSystem();
    void addClassNumber();
    void signIn(string name);
    void addStudent(Student stu);
    Student getStudentById(int i);
    Student getStudentByName(string name);
};