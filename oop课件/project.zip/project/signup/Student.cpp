#include "Student.h"
#include <string>
using namespace std;

int Student::studentNumber = 0;
string Student::getName()
{
    return Name;
}
int Student::getPresentTimes()
{
    return PresentTimes;
}
int Student::getAbsentTimes()
{
    
    return AbsentTimes;
}
Student::Student(string name):Name(name), Id(studentNumber), PresentTimes(0), AbsentTimes(0)
{
    studentNumber++;
}