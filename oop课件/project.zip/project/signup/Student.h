#pragma once
#include <string>
using namespace std;
class Student
{
public:
    string Name;
    int Id;
    int PresentTimes;
    int AbsentTimes;
    static int studentNumber;
public:
    string getName();
    int getPresentTimes();
    int getAbsentTimes();
    Student(string name);
};