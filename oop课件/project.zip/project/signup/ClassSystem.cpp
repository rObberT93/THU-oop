#include "ClassSystem.h"
#include <string>
using namespace std;

void ClassSystem::addClassNumber()
{
    ClassNumber++;
}
void ClassSystem::signIn(string name)
{
    for(int i = 0; i < students.size(); i++)
    {
        if(name == students[i].Name)
        {
            students[i].PresentTimes++;
            
        }
        students[i].AbsentTimes = ClassNumber - students[i].PresentTimes;
    }
}
void ClassSystem::addStudent(Student stu)
{
    students.push_back(stu);
}
Student ClassSystem::getStudentById(int i)
{
    for(int j = 0; j < students.size(); j++)
    {
        if(i == students[j].Id)
        {
            return students[j];
        }
    }
    return students[0];
}
Student ClassSystem::getStudentByName(string name)
{
    for(int j = 0; j < students.size(); j++)
    {
        if(name == students[j].Name)
        {
            return students[j];
        }
    }
    return students[0];
}
ClassSystem::ClassSystem(): ClassNumber(0)
{

}