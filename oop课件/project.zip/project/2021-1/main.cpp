#include <iostream>
using namespace std;

int main()
{
    string a = "zhangsan";
    cout << sizeof(a) << endl;
}
