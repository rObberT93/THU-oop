#include <iostream>
#include <string>
#include <regex>
using namespace std;

smatch sm;
smatch sm1;
smatch sm2;
regex get_name(R"(\"username\"[ ]*:[ ]*\"([a-zA-Z][a-zA-Z0-9_]{3,14})\")");
regex get_password1(R"(\"password\"[ ]*:[ ]*\"([a-zA-Z0-9]{8,20})\")");
regex get_password2(R"([0-9]+)");
regex get_password3(R"([a-zA-Z]+)");
regex get_email(R"(\"email\"[ ]*:[ ]*\"(([0-9a-zA-Z_]+)(@)([0-9a-zA-Z_.]+)))");
string username;
string password;
string email;
string t1;
string t2;
int Nflag = 0;
int Pflag = 0;
int Eflag = 0;

void extract(string input)
{
    
    string t = R"("password": "abc12345")";
    if(regex_search(input, sm, get_name))
    {
        Nflag = 1;
        username = sm[1];
        //cout << "name: " << sm[1] << endl;
            
    }
    if(regex_search(input, sm, get_password1))
    {
        t1 = sm[1].str();
        if(regex_search(t1, sm1, get_password2))
       {
           
           if(regex_search(t1, sm2, get_password3))
           {
               Pflag = 1;
                password = sm[1];
                //cout << "password: " << sm[1] << endl;
           }
       }
            
    }
    if(regex_search(input, sm, get_email))
    {
        Eflag = 1;
        email = sm[1];
        //cout << "email: " << sm[1] << endl;
            
    }
}
void print()
{
    if(Nflag && Pflag && Eflag)
    {
        cout << "Successfully registered." << endl;
        int l = username.size() - 3;
        //cout << l << endl;
        string name(l, '*');
        string code(password.length(), '*');
        regex em(R"([^@.])");
        cout << "username: " << username[0] << username[1] << username[2] << name << endl;
        cout << "password: " << code << endl;
        cout << "email: " << regex_replace(email, em, "*") << endl;
        return;
    }
    cout << "Illegal ";
    if(!Nflag)
    {
        cout << "username";
        if(!Pflag)
        {       
            cout << ",password";  
        }
        if(!Eflag)
        {
            cout << ",email";
        }
       
    }
    else
    {
        if(!Pflag)
        {
            cout << "password";
            if(!Eflag)
            {
                cout << ",email";
            }
        }
        else
        {
            cout << "email";
        }
    }
    cout << endl;
    
    
}

int main()
{
    string input;
    getline(cin, input);
    extract(input);
    print();
}
