#pragma once

class OccupationStrategy {
public:								
	virtual double getSalary(double base, double bonus, double level){
		return 0;
	}
	virtual ~OccupationStrategy() = 0;
};
OccupationStrategy::~OccupationStrategy(){}

class SalesmanStrategy : public OccupationStrategy {
public:
	double getSalary(double base, double bonus, double level)
	{
		double rate;
		switch ((int)level / 10)
		{
		case 6:
			rate = 0.6;
			break;
		case 7:
			rate = 0.7;
			break;
		case 8:
			rate = 1;
			break;
		case 9:
			rate = 1;
			break;
		case 10:
			rate = 1;
			break;
		default:
			rate = 0;
			break;
		}
		return base + bonus * rate;
	}
};

class DeveloperStrategy : public OccupationStrategy {	
public:
	double getSalary(double base, double bonus, double level)
	{
		return base + bonus * level / 100;
	}

};