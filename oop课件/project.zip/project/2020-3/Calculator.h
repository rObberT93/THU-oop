#pragma once
#include <string>
#include "OccupationStrategy.h"
#include "PayStrategy.h"

class Calculator {	
public:
    OccupationStrategy* m_occupationStrategy;
    PayStrategy* m_payStrategy;
    Calculator(OccupationStrategy* &p1, PayStrategy* &p2):m_occupationStrategy(p1), m_payStrategy(p2){}
    double getSalary(double base, double bonus, double level)
    {
        return m_occupationStrategy->getSalary(base, bonus, level);
    }
    double pay(string name, double salary)
    {
        return m_payStrategy->pay(name, salary);
    }
};