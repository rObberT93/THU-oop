#pragma once
#include <string>
#include <iostream>
using namespace std;

class PayStrategy {	
public:							
	virtual double pay(std::string name, double money)
	{
		return 0;
	}
	virtual ~PayStrategy()=0;
};
PayStrategy::~PayStrategy(){}

class NormalStrategy : public PayStrategy {	
public:
	virtual double pay(std::string name, double money)
	{
		return money;
	}

};

class SwiftStrategy : public PayStrategy {	
public:
	virtual double pay(std::string name, double money)
	{
		if(money <= 10000)
		{
			return money - 10;
		}
		else
		{
			double sub = money * 0.001 > 20 ? 20 : money * 0.001;
			return money - sub;
		}
	}

};

class BitcoinStrategy : public PayStrategy {
public:
	virtual double pay(std::string name, double money)
	{
		return money - (name.length() + 8) * 0.01;
	}	

};
