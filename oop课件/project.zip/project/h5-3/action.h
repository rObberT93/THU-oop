#include "animal.h"
#include <iostream>
using namespace std;

void action(Animal* animal, std::vector<Dog> & dogzone, std::vector<Bird> & birdzone)
{
    Dog* pD = dynamic_cast<Dog*>(animal);
    Bird* pB = dynamic_cast<Bird*>(animal);
    if(pD)
    {
        Dog c = move(*pD);
        dogzone.push_back(move(c));
       
    }
    if(pB)
    {
        Bird c = move(*pB);
        birdzone.push_back(move(c));
        
    }

}