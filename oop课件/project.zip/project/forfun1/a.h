#pragma once
#include <iostream>
using namespace std;


void f()
{
    cout << 2 << endl;
}
