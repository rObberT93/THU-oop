#include "a.h"
#include <iostream>

using namespace std;

int main()
{
  int* p = new int (3);
  delete p;
  assert(p == nullptr);
}