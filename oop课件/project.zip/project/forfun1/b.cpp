#include "a.h"
#include <iostream>
using namespace std;

extern int v;
int main()
{
    v++;
    cout << v << endl;
}
