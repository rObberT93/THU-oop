#ifndef PLAYER_H
#define PLAYER_H

#include <iostream>
#include <vector>
#include "audio.h"
#include "video.h"
using namespace std;

class Sound
{
public:
	virtual void play() = 0;
	virtual void pause() = 0;
	virtual int getLength() = 0;
	virtual void doubleSpeed() = 0;
	virtual std::string getName() = 0;
	virtual ~Sound() {}

};



class VideoAdapter:public Sound
{
public:
	Video* p;
	VideoAdapter(Video* &pt):p(pt){}
	virtual void play() override
	{
		p->playVideo();
	}
	virtual void pause() override
	{
		p->pauseVideo();
	}
	virtual int getLength() override
	{
		return p->getLength();
	}
	virtual void doubleSpeed() override
	{
		p->doubleSpeed();
	}
	virtual std::string getName() override
	{
		return p->getName();
	}
	virtual ~VideoAdapter() {}
};

class AudioAdapter:public Sound
{
public:
	Audio* p;
	AudioAdapter(Audio* &pt):p(pt){}
	virtual void play() override
	{
		p->play();
	}
	virtual void pause() override
	{
		p->pause();
	}
	virtual int getLength() override
	{
		return 0;
	}
	virtual void doubleSpeed() override
	{
		cout << "audio cannot be double speed" << endl;
	}
	virtual std::string getName() override
	{
		return p->getName();
	}
	virtual ~AudioAdapter() {}

};




class Player{
	std::vector<Sound*> playlist;
public:
	void add(Sound* aud){
		playlist.push_back(aud);
	}
	void play(){
		if (playlist.empty())
			std::cout << "Nothing to play" << std::endl;
		for (Sound* aud: playlist)
			aud->play();
	}
	void pause(){
		if (playlist.empty())
			std::cout << "Nothing to pause" << std::endl;
		for (Sound* aud: playlist)
			aud->pause();
	}
	void doubleSpeed(){
		if (playlist.empty())
			std::cout << "Nothing to doubleSpeed" << std::endl;
		for (Sound* aud: playlist)
			aud->doubleSpeed();
	}
};

#endif