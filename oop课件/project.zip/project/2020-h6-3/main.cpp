#include <iostream>
#include "player.h"
#include "mp3.h"
#include "wav.h"
#include "mp4.h"
#include "avi.h"

int main(){
	std::cout << "Create a player" << std::endl;
	Player* player = new Player();
	Audio* mp33 = new MP3();
	AudioAdapter mp3(mp33);
	Audio* wavv = new WAV();
	AudioAdapter wav(wavv);
	Video* mp44 = new MP4();
	VideoAdapter mp4(mp44);
	Video* avii = new AVI();
	VideoAdapter avi(avii);
	player->add(&mp3);
	player->add(&wav);
	player->add(&mp4);
	player->add(&avi);
	std::cout << "play all" << std::endl;
	player->play();
	std::cout << "pause all" << std::endl;
	player->pause();
	std::cout << "double speed" << std::endl;
	player->doubleSpeed();
	delete mp33;
	delete wavv;
	delete mp44;
	delete avii;
	delete player;
	return 0;
}
