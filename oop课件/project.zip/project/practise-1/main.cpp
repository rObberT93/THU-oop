#include "Container.h"
#include <string>
#include <iostream>

using namespace std;

/*template<class A>
void work(Container<A> * cont)
{	
	int n;
    cin >> n;
    while(n--)
    {
        int x, y;
		string act;
        cin >> act;
        if(act == "ban")
        {
			A item;
            cin >> x >> y >> item;
            cont->insert(x, y, item);
        }
        else
        {
            cin >> x >> y;
            A* result = cont->find(x,y);
            if (result==NULL)
                cout << "open" << endl;
            else
                cout << *result << endl;
        }
    }
}

template <class A>
void start()
{
    Container<A> * cont = new Container<A>();
    work(cont);
    delete cont;
}

int main()
{
    string type;
    cin >> type;
	
    if(type == "int")
        start<int>();
    else if(type == "string")
        start<string>();
	
	return 0;
}
*/
class A
{
public:
    int data;
    int* p;
    A() = default;
    A(int _data):data(_data)
    {
        p = new int(2);
    }
    A(const A& b):data(b.data),p(new int)
    {
        *p = *(b.p);
    }

};
int main()
{
    A a(3);
    A b = a;
    cout << b.data << " " << *(b.p) << endl;
}