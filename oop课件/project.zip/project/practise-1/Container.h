#pragma once
#include <iostream>
using namespace std;

template<typename T>
class Container
{
public:
    int record[2][1010] = {0};
    T** array;
    int number = 0;

    Container()
    {
        array = new T*[1010];
    }
    T* find(int x, int y)
    {
        int index = 0;
        int flag = 0;
        for(int i = 0; i < number; i++)
        {
            if(record[0][i] == x && record[1][i] == y)
            {
                index = i;
                flag = 1;
                break;
            }
        }
        if(flag == 1)
        {
            return array[index];
        }
        else
        {
            return nullptr;
        }
    }
    void insert(int x, int y, T item)
    {
        record[0][number] = x;
        record[1][number] = y;
        array[number] = new T(item);
        number++;
    }
};