#pragma once
#include "Hero.h"

class SkilledHero : public Hero {
	// TODO
};
OrcHero::OrcHero()
{
	
}