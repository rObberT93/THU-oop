#pragma once
#include "SkilledHero.h"

class BladestormHero : public SkilledHero {
	// TODO
public:
	int level;
	void getSkill(name2Level& skillMap) 
	{
		
	}
	BladestormHero(Hero* &p)
	{

	}
};