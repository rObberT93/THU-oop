#pragma once
#include "card.h"
#include "beggar.h"
#include "soldier.h"
#include <iostream>
using namespace std;

class King:public Card
{
public:
    King(string name = "king"):Card(name)
    {

    }
    int battle(Card* other) override
    {
        
        if(other->name() == "beggar")
        {
            return -1;
        }
        if(other->name() == "soldier")
        {
            return 1;
        }
    }
};