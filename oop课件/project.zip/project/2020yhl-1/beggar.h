#pragma once
#include <string>
using namespace std;
class Beggar:public Card
{
public:
    Beggar(string name = "beggar"):Card(name)
    {

    }
};