#pragma once
#include "king.h"
#include "beggar.h"
#include "card.h"
#include <string>
using namespace std;
class Soldier:public Card
{
public:
    Soldier(string name = "soldier"):Card(name)
    {

    }  
    int battle(Card* other) override
    {
        
        if(other->name() == "beggar")
        {
            return 1;
        }
        if(other->name() == "soldier")
        {
            return 0;
        }
        if(other->name() == "king")
        {
            return -1;
        }
    }  


};