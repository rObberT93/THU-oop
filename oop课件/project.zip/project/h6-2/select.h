#pragma once
#include "Student.h"
#include <iostream>
using namespace std;

vector<int> select(vector<int> credit, int l, int r, Student* student)
{
    credit.insert(credit.begin(), 0);
    return student->choose(credit, l, r);
}