#pragma once
#include <iostream>
#include <cmath>
using namespace std;

bool isPrime(int n)
{
    if(n == 1)
    {
        return false;
    }
    if(n == 2)
    {
        return true;
    }
    for(int i = 2; i <= sqrt(n); i++)
    {
        if(n % i == 0)
        {
            return false;
        }
    }
    return true;
}


class Student
{
public:
    vector<int> result;
    Student()=default;
    virtual vector<int> choose(vector<int> credit, int l, int r)=0;

};

class StudentTypeA:public Student
{
     vector<int> choose(vector<int> credit, int l, int r)override
    {
        
        for(int i = l; i <= r; i++)
        {
            if(credit[i] <= 2)
            {
                result.push_back(i);
            }
        }
        return result;
    }
    
};

class StudentTypeB:public Student
{
     vector<int> choose(vector<int> credit, int l, int r)override
    {
        for(int i = l; i <= r; i++)
        {
            if(isPrime(i))
            {
                result.push_back(i);
            }
        }
        return result;
    }
};

class StudentTypeC:public Student
{
    vector<int> choose(vector<int> credit, int l, int r)override
    {
        for(int i = l; i <= r; i++)
        {
            if(i % credit[i] == 0)
            {
                result.push_back(i);
            }
        }
        return result;
    }
};

