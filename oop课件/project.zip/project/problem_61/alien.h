#pragma once
#include "what.h"
#include <string>
#include <iostream>
using namespace std;

class Alien:public WhatCanMotion, public WhatCanSpeak
{
public:
    string name;
    Alien(string _name):name(_name)
    {

    }
    virtual void stop() override
    {
        cout << name << " stops" << endl;
    }
    virtual void motion() override
    {
        cout << name << " is moving" << endl;
    }
    virtual void speak() override
    {
        cout << name << " is speaking" << endl;
    }

};