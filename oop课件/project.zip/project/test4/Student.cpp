#include "Student.h"
#include <iostream>
using namespace std;
Student::Student(){}
bool Student::operator< (Student a)
{

}
 Student::Student()
 {

 }
ostream& operator<< (ostream&, const Student& a)
{
    cout << a.name << "-Total-" << a.Cgrade+a.Egrade+a.Mgrade << "-Chinese-"
}