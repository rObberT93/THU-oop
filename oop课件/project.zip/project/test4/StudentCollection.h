#pragma once
#include "Student.h"
#include <vector>
#include <string>
using namespace std;

class StudentCollection
{
public:
    vector <Student> students;


public:
    friend istream& operator>> (istream& in, StudentCollection& sc);
    friend ostream& operator<< (ostream& out, const StudentCollection& sc);
    Student& operator[] (string name);
    void sortByScore();
};
// Student& StudentCollection::operator[] (string name){}
