#pragma once
#include <string>
class Student
{
public:
    string name;
    int Cgrade;
    int Mgrade;
    int Egrade;
    int total;
    int index;
public:
    bool operator< (Student a);
    Student();
    friend ostream& operator<< (ostream&, const Student& a);
};