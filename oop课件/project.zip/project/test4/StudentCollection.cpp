#include "StudentCollection.h"
#include "Student.h"
#include <iostream>
#include <string>
using namespace std;

istream& operator>> (istream& in, StudentCollection& sc)
{
    string t = "-";
    string info;
    in >> info;
    int p1 = info.find_first_of(t);
    int p2 = info.find_last_of(t);
    string name = info.substr(0, p1);
    Student a = sc[name];
    a.name = info.substr(0, p1);
    if(info[p1+1] == 'C')
    {
        a.Cgrade = 0;
        for(int i = p2 + 1; i <= info.length() - 1; i++)
        {
            a.Cgrade = a.Cgrade * 10 + info[i];
        }
    }
    else if(info[p1+1] == 'M')
    {
        a.Mgrade = 0;
        for(int i = p2 + 1; i <= info.length() - 1; i++)
        {
            a.Mgrade = a.Mgrade * 10 + info[i];
        }
    }
    else if(info[p1+1] == 'E')
    {
        a.Egrade = 0;
        for(int i = p2 + 1; i <= info.length() - 1; i++)
        {
            a.Egrade = a.Egrade * 10 + info[i];
        }
    }
    return in;
    
}
ostream& operator<< (ostream& out, const StudentCollection& sc)
{
    
}

Student& StudentCollection::operator[] (string name)
{
    
    for(int i = 0; i < students.size(); i++)
        {
            if(students[i].name == name)
            {
                return students[i];
            }
            students[0].flag = 0;
            return students[0];
        }
   Student temp;
   students.push_back(temp);
   return temp;
    
}
void StudentCollection::sortByScore()
{

}