#pragma once
#include "User.h"
#include "VerificationStrategy.h"
#include "EncryptStrategy.h"
#include <iostream>
using namespace std;

class UserProxy
{
public:
    RealUser* ruser;
    EncryptStrategy* encStr;
    VerificationStrategy* verStr;
    UserProxy(RealUser* &r, EncryptStrategy* &e, VerificationStrategy* &v):ruser(r), encStr(e), verStr(v)
    {
        
    }
    void sendMessage(string message)
    {
        ruser->sendMessage(encStr->encode(message));
        cout << verStr->verify(message) << endl;

    }
};