#pragma once
# include <string>
using namespace std;

class VerificationStrategy{
public:
	virtual string verify(std::string mes) = 0;
	string v;
};

class PrefixStrategy:public VerificationStrategy
{
public:

	string verify(string mes)
	{
		for(int i = 0; i < 3; i++)
		{
			v.push_back(mes[i]);
		}
		return v;
		
	}
};

class IntervalStrategy:public VerificationStrategy
{
public:

	string verify(string mes)
	{
		for(int i = 0; i <= mes.size() - 1; i++)
		{
			if(i % 2 == 0)
			{
				v.push_back(mes[i]);
			}
			
		}
		return v;
	}
};
