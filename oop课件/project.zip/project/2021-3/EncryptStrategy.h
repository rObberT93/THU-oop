#pragma once
# include <string>
#include<vector>
#include <iostream>
using namespace std;

class EncryptStrategy{
public:
	virtual string encode(string mes) = 0;
};

class InsertStrategy:public EncryptStrategy
{
public:
	string code;
	InsertStrategy()
	{

	}
	string encode(string mes) 
	{
		
		for(auto &x : mes)
		{
			code.push_back(x);
			code.push_back('#');
		}
		return code;
	}
};

class InvertStrategy:public EncryptStrategy
{
public:
	string code;
	string encode(string mes) 
	{
		for(int i = mes.size() - 1; i >= 0; i--)
		{
			code.push_back(mes[i]);
		}
		return code;
	}
};

