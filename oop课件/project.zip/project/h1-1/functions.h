#pragma once
int sum(int a, int b);
int product(int a, int b);
