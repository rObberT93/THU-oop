#include <iostream>
#include <list>
#include <algorithm>

void choiceE(std::list<int> lst) {
    auto result = std::find(lst.begin(), lst.end(), 4);
    lst.erase(result);
    --result;
    std::cout << *result << std::endl; // (3)
}

int main() {
    std::list<int> lst;
    for (int i = 0; i < 5; ++i) {
        lst.push_back(i * 2);
    }
    choiceE(lst);
    return 0;
}