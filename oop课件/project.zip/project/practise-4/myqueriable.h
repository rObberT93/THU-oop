#pragma once
#include <vector>
#include <iostream>
#include <functional>
#include <list>
using namespace std;

template<typename T>
class MyQueriable
{
public:
    vector<T> array;
    int size()
    {
        return array.size();
    }
    T operator[](int index)
    {
        return array[index];
    }
    MyQueriable where(function<bool(T)> f)
    {
        MyQueriable<T> c;
        for(auto x : array)
        {
            if(f(x) == true)
            {
                c.array.push_back(x);
            }
        }
        return c;
    }
    
    MyQueriable apply(function<T(T)> f)
    {
        MyQueriable<T> c;
        for(auto x : array)
        {
            c.array.push_back(f(x));
        }
        return c;
    }
    T sum()
    {
        T tmp = 0;
        for(auto x : array)
        {
            tmp += x;
        }
        return tmp;
    }
    
};

template<typename T>
MyQueriable<T> from(vector<T> v)
{
     MyQueriable<T> c;   
    for(auto x : v)
    {
        c.array.push_back(x);
    }
    return c;
}
template<typename T>
MyQueriable<T> from(list<T>& v)
{
     MyQueriable<T> c;   
    for(auto &x : v)
    {
        c.array.push_back(x);
        //cout << c.array.size() << endl;
    }
    return c;
}