#pragma once
#include <iostream>
using namespace std;

class Vehicle
{
public:
    int wheel;
    int wing;
    int max_wheel;
    int max_wing;
    Vehicle():wheel(0), wing(0)
    {

    }
    void set_max_wheel_num(int max_wheel_)
    {
        max_wheel = max_wheel_;
    }
    void set_max_wing_num(int max_wing_)
    {
        max_wing = max_wing_;
    }
    void add_wheel()
    {
        wheel++;
    }
    void add_wing()
    {
        wing++;
    }
    bool finished()
    {
        return wheel == max_wheel;
    }
   
    void run() 
    {
        cout << "I am running" << endl;
    }
    
};