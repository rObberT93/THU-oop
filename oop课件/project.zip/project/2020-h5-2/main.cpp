#include <iostream>
#include <regex>
#include <vector>
using namespace std;

regex name(R"((I am |My name is )([a-zA-Z]+))");
regex birth(R"(([0-9]{4})[-.]([0-9]+)[-.]([0-9]+))");
regex tel(R"([0-9]{11})");
regex email(R"([0-9a-zA-Z.]+@[0-9a-zA-Z.]+)");
smatch sm;
vector<string> names;
vector<string> dates;
vector<string> tels;
vector<string> emails;
void extract(string info)
{
    getline(cin, info);
        if(regex_search(info, sm, name))
        {
            cout << sm[2] << endl;
            names.push_back(sm[2].str());
        }
        if(regex_search(info, sm, birth))
        {
            string year = sm[1].str();
            string month = sm[2].str();
            string date = sm[2].str();
            if(month.length() == 1)
            {
                month.insert(month.begin(), '0');
            }
            if(date.length() == 1)
            {
                date.insert(date.begin(), '0');
            }
            year = year + "." + month + "." + date;
            cout << year << endl;
            dates.push_back(year);
        }
        if(regex_search(info, sm, tel))
        {
            cout << sm[0] << endl;
            tels.push_back(sm[0].str());
        }
        if(regex_search(info, sm, email))
        {
            cout << sm[0] << endl;
            emails.push_back(sm[0].str());
        }
}

int main()
{
    int n;
    cin >> n;
    for(int i = 0; i < n + 1; i++)
    {
        string info;
        getline(cin, info);
        extract(info);
    }
}