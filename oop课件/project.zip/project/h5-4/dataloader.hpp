#include <map>
#include <vector>
#include <string>
#include <iostream>
#include <cstring>
#include<sstream>


using namespace std;



// Change this file as you want or add more files






class Vocabulary
{
private:
public:
    // Choose a proper container from STL.
    map<string, int> words;
    static int id;
public:
    vector<int> insertSentReturnIds(string sentence)
    {
        //Enter your code here.
        //This function should build vocabulary and at the same time return a sentence encoding.
        string word;
        vector<int> encoding;
        istringstream is(sentence);
        while(is >> word)
        {
            
            if(words.find(word) == words.end())
            {
                id++;
                words[word] = id;
            }
            encoding.push_back(words[word]);

        }
        return encoding;
    }
};
int Vocabulary::id = 0;





class DataLoader{
private:
    vector<int> _rand_order;
    int batch_size=0;
    //Enter your code here
public:
    vector<vector<int>> data;
    vector<vector<int>> newData;
    int length = 0;

    void setBatchSize(int N)
    {
        this->batch_size = N; // can also change
    
    }

    void setOrder(vector<int>& x){
        _rand_order = x; // can also change
        newData.clear();
        for(int i : x)
        {
            newData.push_back(data[i]);
        }

    }

    void addData(vector<int> sent_encoding){
        //Enter you code here;
        data.push_back(sent_encoding);
        
    }

    struct Iterator
    {
        using iterator_category = std::forward_iterator_tag;
        using difference_type   = std::ptrdiff_t;
        using value_type = int;
        using reference = vector<vector<value_type>>;

        //Define your constructor and functions that are needed for a Iterator.
        reference* _p;
        int index;
        int batch_size;
        int max_index;
        difference_type t;
        Iterator(int x, reference& newData, int _batch_size):index(x),_p(&newData),batch_size(_batch_size)
        {
            if(_p->size() % batch_size == 0)
            {
                max_index = (_p->size() / batch_size -1)* batch_size;
            }
            else
            {
                max_index = _p->size() / batch_size * batch_size;
            }
            
        }
        void operator++()
        {
            index += batch_size;
        }
        bool operator!=(const Iterator& a) const
        {
            return index != a.index;
        }
        reference operator*()
        {
            vector<vector<int>> c;
            int len = 0;
            if(index != max_index)
            {
                for(int i = 0; i < batch_size; i++)
                {
                    c.push_back((*_p)[index+i]);
                    if((*_p)[index+i].size() > len)
                    {
                        len = (*_p)[index+i].size();
                    }
                }

            }
            else{
                for(int i = index; i < _p->size(); i++)
                {
                    c.push_back((*_p)[i]);
                    if((*_p)[i].size() > len)
                    {
                        len = (*_p)[i].size();
                    }
                }
            }
            for(auto &x : c)
            {
                if(x.size() < len)
                {
                    int l = x.size();
                    for(int i = 0; i < len - l; i++)
                    {
                        x.push_back(0);
                    }
                }
            }
            return c;
        }
        

        private:
        // Add what where variable you want here to make the Iterator functional.

    };
    

    Iterator begin() {
        //Enter your code here.
        Iterator c(0, newData, batch_size);
        return c;
    }
    Iterator end() {
        //Enter your code here.
        if(newData.size() % batch_size != 0)
        {
            Iterator c((newData.size()/batch_size + 1)*batch_size, newData, batch_size);
            return c;
        }
        else
        {
            Iterator c((newData.size()/batch_size)*batch_size, newData, batch_size);
            return c;
        }
        
    }
    

    

};






